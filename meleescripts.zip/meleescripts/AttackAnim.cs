﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackAnim : MonoBehaviour {

	public GameObject TestStick;
	public GameObject TestStickIdle;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Mouse0)) {
			TestStick.gameObject.SetActive (true);
			Invoke ("Clearweapon", 1);
			TestStickIdle.gameObject.SetActive (false);
		}
		
	}
	void Clearweapon () {
		TestStick.gameObject.SetActive (false);
		TestStickIdle.gameObject.SetActive (true);
	}
}
